# calculadora

Descrição. 
Esse pacote serve para realizar as quatro operações matemática básica:
	- adição
	- subtração
	- multiplicação
	- divisão

## Instalação

Use o gerenciador de pacote [pip](https://pip.pypa.io/en/stable/) para instalar o pacote calculadora

```bash
pip install calculadora
```

## Usage

```python
from calculadora import basica

basica.soma(1,2,3,4)
```

## Autor
Juvenal Fonseca

## License
[MIT](https://choosealicense.com/licenses/mit/)
